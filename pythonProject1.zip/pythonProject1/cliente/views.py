from django.shortcuts import render
from .models import Cliente


def fcliente(request):
    clientes = Cliente.objects.all()
    return render(request, "cliente.html",{"clientes":clientes})